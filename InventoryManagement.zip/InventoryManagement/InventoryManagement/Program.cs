﻿using InventoryManagement.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InventoryManagement
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("\t\t"); Console.WriteLine("Welcome to Inventory Management System !!!"); Console.WriteLine(); Console.WriteLine();
            OrderInvoker orderInvoker = new OrderInvoker();

            orderInvoker.ExecuteCommand(CommandOption.Create, "Book01", 10.50, 13.79);
            orderInvoker.ExecuteCommand(CommandOption.Create, "Food01", 1.47, 3.98);
            orderInvoker.ExecuteCommand(CommandOption.Create, "Med01", 30.63, 34.29);
            orderInvoker.ExecuteCommand(CommandOption.Create, "Tab01", 57.00, 84.98);
            orderInvoker.ExecuteCommand(CommandOption.UpdateBuy, "Tab01", 100);
            orderInvoker.ExecuteCommand(CommandOption.UpdateSell, "Tab01", 2);
            orderInvoker.ExecuteCommand(CommandOption.UpdateBuy, "Food01", 500);
            orderInvoker.ExecuteCommand(CommandOption.UpdateBuy, "Book01", 100);
            orderInvoker.ExecuteCommand(CommandOption.UpdateBuy, "Med01", 100);             
            orderInvoker.ExecuteCommand(CommandOption.UpdateSell, "Food01", 1);             
            orderInvoker.ExecuteCommand(CommandOption.UpdateSell, "Food01", 1);             
            orderInvoker.ExecuteCommand(CommandOption.UpdateSell, "Tab01", 2);              
            orderInvoker.InventoryReport();
            orderInvoker.ExecuteCommand(CommandOption.Delete, "Book01");
            orderInvoker.ExecuteCommand(CommandOption.UpdateSell, "Tab01",5);
            orderInvoker.ExecuteCommand(CommandOption.Create, "Mobi01",10.51,44.56);
            orderInvoker.ExecuteCommand(CommandOption.UpdateBuy, "Mobi01",250);
            orderInvoker.ExecuteCommand(CommandOption.UpdateSell, "Food01",5);
            orderInvoker.ExecuteCommand(CommandOption.UpdateSell, "Mobi01",4);
            orderInvoker.ExecuteCommand(CommandOption.UpdateSell, "Med01",10);
            orderInvoker.InventoryReport();
            //In-office Extension
            //orderInvoker.ExecuteCommand(CommandOption.UpdateSellPrice, "Food01", 3.50);
            //orderInvoker.ExecuteCommand(CommandOption.UpdateSell, "Food01", 10);
            //orderInvoker.InventoryReport();

            Console.ReadKey();
        }
        
        
    }
}
