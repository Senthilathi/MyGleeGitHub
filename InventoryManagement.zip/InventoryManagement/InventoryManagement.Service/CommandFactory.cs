﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InventoryManagement.Service
{
    public class CommandFactory
    {
        public OrderCommand GetInstance(CommandOption commandOption)
        {
            switch (commandOption)
            {
                case CommandOption.Create:
                    return new CreateOrder();
                    
                case CommandOption.UpdateBuy:
                    return new UpdateBuyOrder();

                case CommandOption.UpdateSell:
                    return new UpdateSellOrder();
                
                case CommandOption.Delete:
                    return new DeleteOrder();

                case CommandOption.UpdateSellPrice:
                    return new UpdateSellingPrice();

                default:
                    return new CreateOrder();
                    break;
            }
        }
    }
}
