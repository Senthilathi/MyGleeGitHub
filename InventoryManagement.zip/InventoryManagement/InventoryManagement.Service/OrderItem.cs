﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InventoryManagement.Service
{
    /// <summary>
    /// This is class is used for Receiver
    /// </summary>
    public class OrderItem
    {
        public List<Item> StockItems { get; set; }

        public OrderItem()
        {
            StockItems = new List<Item>();
        }

        public void ExecuteItem(OrderCommand orderCommand, Item item)
        {
            orderCommand.Execute(this.StockItems, item);
        }

        public void DisplayStockReport()
        {
            foreach (var item in StockItems.Where(X=>X.IsDelete ==false).OrderBy (X=>X.Name))
            {
                item.DisplayStockItem();                
            }
        }
       public void DisplayTotalAndProfit()
        {
            double profitAmount = (StockItems.Where(X => X.IsDelete == false).Sum(item => item.ProfitAmount)) - (StockItems.Where(X => X.IsDelete == true).Sum(X => X.AvailableQuantity * X.BuyingPrice));
            Console.Write("Total Value \t\t\t\t\t\t\t"); Console.Write(StockItems.Where (X=>X.IsDelete ==false).Sum(item => item.Total)); Console.WriteLine();
            Console.Write("Profit since previous report \t\t\t\t\t"); Console.Write(profitAmount); (from p in StockItems where p.IsDelete  == false select p).ToList().ForEach(x => x.ProfitAmount = 0);
            Console.WriteLine();
        }
    }
}
