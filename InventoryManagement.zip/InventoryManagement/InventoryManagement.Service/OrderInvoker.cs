﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InventoryManagement.Service
{
    public class OrderInvoker
    {
        private OrderCommand orderCommand;
        private Item item;
        private OrderItem orderItem;

        public OrderInvoker()
        {
            orderItem = new OrderItem();
        }

        public void GetInstance(CommandOption commandOption)
        {
            orderCommand = new CommandFactory().GetInstance(commandOption);
        }

        public void AssignItem(Item item)
        {
            this.item = item;
        }

        public void ExecuteCommand()
        {
            orderItem.ExecuteItem(orderCommand, this.item);
        }
        
        public void ExecuteCommand(CommandOption commandType, string itemName, double buyingPrice, double sellingPrice)
        {
            this.GetInstance(commandType);
            this.AssignItem(new Item(itemName, buyingPrice, sellingPrice));
            this.ExecuteCommand();
        }

        public void ExecuteCommand(CommandOption commandType, string itemName, int quantity)
        {
            this.GetInstance(commandType);
            this.AssignItem(new Item(itemName, quantity));
            this.ExecuteCommand();
        }

        public void ExecuteCommand(CommandOption commandType, string itemName)
        {
            this.GetInstance(commandType);
            this.AssignItem(new Item(itemName));
            this.ExecuteCommand();
        }
        //In-Office Extension
        public void ExecuteCommand(CommandOption commandType, string itemName, double sellingPrice)
        {
            this.GetInstance(commandType);
            this.AssignItem(new Item(itemName,sellingPrice));
            this.ExecuteCommand();
        }
        public void DisplayCurrentStock()
        {
            orderItem.DisplayStockReport();
        }

        public void InventoryReport()
        {
            this.Header();
            this.DrawLine();
            this.DisplayCurrentStock();
            this.DrawSingleLine();
            this.DisplayTotalAndProfit();
        }
        public void Header()
        {
            Console.Write("\t\t\t"); Console.Write("INVENTORY REPORT"); Console.WriteLine(); Console.WriteLine();
            Console.Write("Item Name"); Console.Write("\t");
            Console.Write("Bought At"); Console.Write("\t");
            Console.Write("Sold At"); Console.Write("\t\t");
            Console.Write("Available Qty"); Console.Write("\t");
            Console.Write("Value"); Console.WriteLine();
        }
        public void DrawLine()
        {
            Console.Write("----------"); Console.Write("\t");
            Console.Write("----------"); Console.Write("\t");
            Console.Write("-------"); Console.Write("\t\t");
            Console.Write("------------"); Console.Write("\t");
            Console.Write("------"); Console.WriteLine();

        }
        public void DrawSingleLine()
        {
            Console.Write("--------------------------------------------------------------------------------\t");
            Console.WriteLine();
        }
        public void DisplayTotalAndProfit()
        {
            orderItem.DisplayTotalAndProfit();
            Console.WriteLine();
        }        
    }
}
