﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InventoryManagement.Service
{
    public enum CommandOption
    {
        Create,
        UpdateBuy,
        UpdateSell,
        Delete,
        UpdateSellPrice
    }
}
